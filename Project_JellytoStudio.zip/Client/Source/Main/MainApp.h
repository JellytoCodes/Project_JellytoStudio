#pragma once

#include "Core/Interfaces/IExecute.h"

class Scene;
class Entity;
class Actor;

class MainApp : public IExecute
{
public:
	virtual void Init()   override;
	virtual void Update() override;
	virtual void Render() override;

private:
	void RegisterActors();      // ItemWindow�� Actor ���丮 ���
	void SpawnDefaultActors();  // �⺻ Actor ����
	void CreateCamera();

	void UpdatePicking();
	void FillDetailInfo(std::shared_ptr<Entity> entity, DetailInfo& info);

	std::vector<std::shared_ptr<Actor>> _defaultActors;

	std::shared_ptr<Entity> _pickedEntity;
};