﻿#include "pch.h"
#include "PointClickController.h"

#include "Entity/Entity.h"
#include "Entity/Components/Transform.h"
#include "Entity/Components/AnimStateMachine.h"
#include "Entity/Components/Collider/BaseCollider.h"
#include "Entity/Components/Collider/AABBCollider.h"
#include "Core/Managers/InputManager.h"
#include "Core/Managers/TimeManager.h"
#include "Scene/Scene.h"
#include "Scene/SceneManager.h"
#include "Scene/ChunkManager.h"

PointClickController::PointClickController() {}

void PointClickController::Awake()
{
    UpdateAnimState(false);
}

void PointClickController::Update()
{
    HandleInput();
    if (_isMoving)
        MoveToDestination(GET_SINGLE(TimeManager)->GetDeltaTime());
}

void PointClickController::HandleInput()
{
    if (!GET_SINGLE(InputManager)->GetButtonDown(KEY_TYPE::RBUTTON)) return;

    Scene* scene = GET_SINGLE(SceneManager)->GetCurrentScene();
    if (!scene) return;

    const POINT mp = GET_SINGLE(InputManager)->GetMousePos();

    Entity* hitEntity = nullptr;
    Vec3    hitNormal;
    float   hitDist;

    if (!scene->PickBlock((int32)mp.x, (int32)mp.y,
        _walkChannel, hitEntity, hitNormal, hitDist))
        return;

    if (hitNormal.y < 0.7f) return;

    AABBCollider* aabb = hitEntity->GetComponent<AABBCollider>();
    if (!aabb) return;

    const BoundingBox& box = aabb->GetBoundingBox();
    const float        blockTopY = box.Center.y + box.Extents.y;

    Vec3 dest(box.Center.x, blockTopY, box.Center.z);
    MoveTo(dest);
}

void PointClickController::MoveTo(const Vec3& worldPos)
{
    _destination = worldPos;
    _isMoving = true;
    UpdateAnimState(true);
}

void PointClickController::MoveToDestination(float dt)
{
    Transform* transform = GetTransform();   // MonoBehaviour → Component::GetTransform()
    if (!transform) return;

    Vec3  pos = transform->GetLocalPosition();
    Vec3  toTarget = _destination - pos;
    float dist = toTarget.Length();

    if (dist <= _stopThreshold)
    {
        transform->SetLocalPosition(_destination);
        _isMoving = false;
        UpdateAnimState(false);
        return;
    }

    Vec3  dir = toTarget / dist;
    float moveStep = std::min(_moveSpeed * dt, dist);

    Vec3 nextPosXZ(pos.x + dir.x * moveStep, pos.y, pos.z + dir.z * moveStep);
    if (IsMovementBlocked(nextPosXZ))
    {
        _isMoving = false;
        UpdateAnimState(false);
        return;
    }

    Vec3  dirXZ = Vec3(dir.x, 0.f, dir.z);
    float xzLen = dirXZ.Length();
    if (xzLen > 0.001f)
    {
        dirXZ /= xzLen;
        float targetYaw = atan2f(-dirXZ.x, -dirXZ.z);
        Vec3  curRot = transform->GetLocalRotation();
        float diff = targetYaw - curRot.y;
        while (diff > XM_PI) diff -= XM_2PI;
        while (diff < -XM_PI) diff += XM_2PI;
        float step = XMConvertToRadians(_rotateSpeed) * dt;
        curRot.y += (fabsf(diff) <= step) ? diff : (diff > 0.f ? step : -step);
        transform->SetLocalRotation(curRot);
    }

    transform->SetLocalPosition(pos + dir * moveStep);

    if (auto* col = GetEntity()->GetComponent<AABBCollider>())
        col->InvalidateBounds();
}

// ── 블록 측면 충돌 체크 ───────────────────────────────────────────────────

bool PointClickController::IsMovementBlocked(const Vec3& nextEntityPos) const
{
    Scene* scene = GET_SINGLE(SceneManager)->GetCurrentScene();
    if (!scene) return false;

    // Component::_entity 는 Entity* (raw pointer) — .lock() 없음
    // 이전 코드의 _entity.lock() 는 컴파일 오류
    Entity* selfEntity = _entity;
    if (!selfEntity) return false;

    AABBCollider* charAabb = selfEntity->GetComponent<AABBCollider>();
    if (!charAabb) return false;

    const BoundingBox& curBox = charAabb->GetBoundingBox();
    const Vec3         charExtents = curBox.Extents;

    // Entity에는 GetTransform()이 없음 → GetComponent<Transform>() 사용
    Transform* tf = selfEntity->GetComponent<Transform>();
    if (!tf) return false;
    const float curEntityY = tf->GetLocalPosition().y;
    const float colOffsetY = curBox.Center.y - curEntityY;

    BoundingBox nextCharBox;
    nextCharBox.Center = Vec3(nextEntityPos.x,
        nextEntityPos.y + colOffsetY,
        nextEntityPos.z);
    nextCharBox.Extents = charExtents;

    const float charFeetY = nextEntityPos.y;

    std::vector<BaseCollider*> candidates;
    candidates.reserve(32);
    GET_SINGLE(ChunkManager)->CollectStaticColliders(nextCharBox, candidates);

    for (BaseCollider* candidate : candidates)
    {
        if (!candidate || candidate->GetEntity() == selfEntity) continue;
        AABBCollider* blockAabb = dynamic_cast<AABBCollider*>(candidate);
        if (!blockAabb) continue;

        if (blockAabb->GetOwnChannel() != CollisionChannel::Priming) continue;

        const BoundingBox& blockBox = blockAabb->GetBoundingBox();

        // XZ 사전 컬링
        {
            const float dx = blockBox.Center.x - nextEntityPos.x;
            const float dz = blockBox.Center.z - nextEntityPos.z;
            if (dx * dx + dz * dz > 4.0f) continue;
        }

        const float blockTopY = blockBox.Center.y + blockBox.Extents.y;
        if (blockTopY <= charFeetY + 0.05f) continue;

        if (nextCharBox.Intersects(blockBox))
            return true;
    }

    return false;
}

// ── 애니메이션 ────────────────────────────────────────────────────────────

void PointClickController::UpdateAnimState(bool moving)
{
    // Component::_entity 는 Entity* (raw pointer) — .lock() 없음
    Entity* entity = _entity;
    if (!entity) return;

    AnimStateMachine* asm_ = entity->GetComponent<AnimStateMachine>();
    if (!asm_) return;

    if (asm_->IsState(AnimState::Die) || asm_->IsState(AnimState::Attack)) return;
    asm_->SetState(moving ? AnimState::Walk : AnimState::Idle);
}
