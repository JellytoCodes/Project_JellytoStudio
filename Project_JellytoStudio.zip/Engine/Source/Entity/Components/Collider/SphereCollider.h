﻿#pragma once
#include "BaseCollider.h"

class SphereCollider : public BaseCollider
{
	using Super = BaseCollider;

public:
	SphereCollider();
	virtual ~SphereCollider();

	bool Intersects(Ray& ray, float& distance) override;
	bool Intersects(std::shared_ptr<BaseCollider>& other) override;

	BoundingSphere& GetBoundingSphere()				{ return _boundingSphere; }

	float GetRadius() const							{ return _radius; }
	void SetRadius(float r)							{ _radius = r; }

protected:
	void UpdateBounds() override;

	// 디버그 시각화
	std::wstring GetDebugMeshKey() const override	{ return L"Sphere"; }
	Vec4         GetDebugColor()   const override	{ return Vec4(1.f, 1.f, 0.f, 1.f); }
	Matrix       GetDebugWorldMatrix() override;

private:
	float			_radius = 0.f;
	BoundingSphere	_boundingSphere = {};
};