﻿#pragma once
#include "BaseCollider.h"

class AABBCollider : public BaseCollider
{
	using Super = BaseCollider;

public:
	AABBCollider();
	virtual ~AABBCollider();

	bool Intersects(Ray& ray, float& distance) override;
	bool Intersects(std::shared_ptr<BaseCollider>& other) override;

	BoundingBox& GetBoundingBox()					{ return _boundingBox; }

	Vec3 GetBoxExtents() const						{ return _boxExtents; }
	void SetBoxExtents(const Vec3& e)				{ _boxExtents = e; }

protected:
	void UpdateBounds() override;

	std::wstring GetDebugMeshKey() const override	{ return L"Cube"; }
	Vec4         GetDebugColor()   const override	{ return Vec4(1.f, 0.f, 0.f, 1.f); }
	Matrix       GetDebugWorldMatrix() override;

private:
	Vec3		_boxExtents = { 0.f, 0.f, 0.f };
	BoundingBox	_boundingBox = {};
};