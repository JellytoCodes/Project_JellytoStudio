#include "Framework.h"
#include "MonoBehaviour.h"

MonoBehaviour::MonoBehaviour()
	: Super(ComponentType::Script)
{

}

MonoBehaviour::~MonoBehaviour()
{

}

void MonoBehaviour::Awake()
{
	
}

void MonoBehaviour::Start()
{
	
}

void MonoBehaviour::Update()
{
	
}

void MonoBehaviour::LateUpdate()
{
	
}

void MonoBehaviour::OnDestroy()
{
	
}

void MonoBehaviour::OnCollision(std::shared_ptr<Entity>& other)
{

}
