#pragma once
#include "Entity/Components/Transform.h"

class MonoBehaviour;
class Widget;

class Entity
{
public:
    Entity(const std::wstring& name);
    virtual ~Entity();

    virtual void Awake();
    virtual void Start();
    virtual void Update();
    virtual void LateUpdate();
    virtual void OnDestroy();

    void OnCollision(Entity* other);

    void AddComponent(std::unique_ptr<Component> component);

    template <typename T>
    T* GetComponent();

    void SetLayerIndex(const uint8 layer)   { _layerIndex = layer; }
    uint8 GetLayerIndex() const             { return _layerIndex;  }

    std::wstring GetEntityName() const      { return _entityName; }

protected:
    std::array<std::unique_ptr<Component>, FIXED_COMPONENT_COUNT>   _components;
    std::vector<std::unique_ptr<MonoBehaviour>>                     _scripts;

    uint8                                                           _layerIndex = 0;
    std::wstring                                                    _entityName = L"";
};

template <typename T>
T* Entity::GetComponent()
{
    constexpr int8 kIndex = static_cast<int8>(ComponentTypeOf<T>::kType);

    static_assert(kIndex >= 0, "ComponentType �ε����� �����Դϴ�. ComponentTypeOf Ư��ȭ�� Ȯ���ϼ���.");
    static_assert(kIndex < static_cast<int8>(FIXED_COMPONENT_COUNT), "Script Ÿ���� GetComponent�� �ƴ� GetScript<T>()�� ����ϼ���.");

    return static_cast<T*>(_components[kIndex].get());
}
