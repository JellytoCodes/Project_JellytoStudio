﻿#include "Framework.h"
#include "Shader.h"
#include "Graphics/Graphics.h"
#include "Utils/Utils.h"

Shader::Shader(const std::wstring& file) : _file(L"..\\Shaders\\" + file)
{
	_initialStateBlock = std::make_unique<StateBlock>();
	{
		auto dc = GET_SINGLE(Graphics)->GetDeviceContext();
		dc->RSGetState(_initialStateBlock->RSRasterizerState.GetAddressOf());
		dc->OMGetBlendState(_initialStateBlock->OMBlendState.GetAddressOf(), _initialStateBlock->OMBlendFactor, &_initialStateBlock->OMSampleMask);
		dc->OMGetDepthStencilState(_initialStateBlock->OMDepthStencilState.GetAddressOf(), &_initialStateBlock->OMStencilRef);
	}

	CreateEffect();
}

Shader::~Shader() {}

void Shader::CreateEffect()
{
	_shaderDesc = ShaderManager::GetEffect(_file);

	_shaderDesc.effect->GetDesc(&_effectDesc);
	for (UINT t = 0; t < _effectDesc.Techniques; t++)
	{
		Technique technique;
		technique.technique = _shaderDesc.effect->GetTechniqueByIndex(t);
		technique.technique->GetDesc(&technique.desc);
		technique.name = Utils::ToWString(technique.desc.Name);

		for (UINT p = 0; p < technique.desc.Passes; p++)
		{
			ShaderPass pass;
			pass.pass = technique.technique->GetPassByIndex(p);
			pass.pass->GetDesc(&pass.desc);
			pass.name = Utils::ToWString(pass.desc.Name);
			pass.pass->GetVertexShaderDesc(&pass.passVsDesc);
			pass.passVsDesc.pShaderVariable->GetShaderDesc(pass.passVsDesc.ShaderIndex, &pass.effectVsDesc);

			for (UINT s = 0; s < pass.effectVsDesc.NumInputSignatureEntries; s++)
			{
				D3D11_SIGNATURE_PARAMETER_DESC desc;
				HRESULT hr = pass.passVsDesc.pShaderVariable->GetInputSignatureElementDesc(
					pass.passVsDesc.ShaderIndex, s, &desc);
				CHECK(hr);
				pass.signatureDescs.push_back(desc);
			}

			pass.inputLayout = CreateInputLayout(_shaderDesc.blob, &pass.effectVsDesc, pass.signatureDescs);
			pass.stateBlock = _initialStateBlock.get();
			technique.passes.push_back(pass);
		}
		_techniques.push_back(technique);
	}

	for (UINT i = 0; i < _effectDesc.ConstantBuffers; i++)
	{
		ID3DX11EffectConstantBuffer* iBuffer = _shaderDesc.effect->GetConstantBufferByIndex(i);
		D3DX11_EFFECT_VARIABLE_DESC vDesc;
		iBuffer->GetDesc(&vDesc);
	}

	for (UINT i = 0; i < _effectDesc.GlobalVariables; i++)
	{
		ID3DX11EffectVariable* effectVariable = _shaderDesc.effect->GetVariableByIndex(i);
		D3DX11_EFFECT_VARIABLE_DESC vDesc;
		effectVariable->GetDesc(&vDesc);
	}
}

ComPtr<ID3D11InputLayout> Shader::CreateInputLayout(
	ComPtr<ID3DBlob> fxBlob,
	D3DX11_EFFECT_SHADER_DESC* effectVsDesc,
	std::vector<D3D11_SIGNATURE_PARAMETER_DESC>& params)
{
	std::vector<D3D11_INPUT_ELEMENT_DESC> inputLayoutDesc;

	for (D3D11_SIGNATURE_PARAMETER_DESC& paramDesc : params)
	{
		D3D11_INPUT_ELEMENT_DESC elementDesc;
		elementDesc.SemanticName = paramDesc.SemanticName;
		elementDesc.SemanticIndex = paramDesc.SemanticIndex;
		elementDesc.InputSlot = 0;
		elementDesc.AlignedByteOffset = D3D11_APPEND_ALIGNED_ELEMENT;
		elementDesc.InputSlotClass = D3D11_INPUT_PER_VERTEX_DATA;
		elementDesc.InstanceDataStepRate = 0;

		if (paramDesc.Mask == 1) { if (paramDesc.ComponentType == D3D_REGISTER_COMPONENT_UINT32) elementDesc.Format = DXGI_FORMAT_R32_UINT;           else if (paramDesc.ComponentType == D3D_REGISTER_COMPONENT_SINT32) elementDesc.Format = DXGI_FORMAT_R32_SINT;           else if (paramDesc.ComponentType == D3D_REGISTER_COMPONENT_FLOAT32) elementDesc.Format = DXGI_FORMAT_R32_FLOAT; }
		else if (paramDesc.Mask <= 3) { if (paramDesc.ComponentType == D3D_REGISTER_COMPONENT_UINT32) elementDesc.Format = DXGI_FORMAT_R32G32_UINT;        else if (paramDesc.ComponentType == D3D_REGISTER_COMPONENT_SINT32) elementDesc.Format = DXGI_FORMAT_R32G32_SINT;        else if (paramDesc.ComponentType == D3D_REGISTER_COMPONENT_FLOAT32) elementDesc.Format = DXGI_FORMAT_R32G32_FLOAT; }
		else if (paramDesc.Mask <= 7) { if (paramDesc.ComponentType == D3D_REGISTER_COMPONENT_UINT32) elementDesc.Format = DXGI_FORMAT_R32G32B32_UINT;     else if (paramDesc.ComponentType == D3D_REGISTER_COMPONENT_SINT32) elementDesc.Format = DXGI_FORMAT_R32G32B32_SINT;     else if (paramDesc.ComponentType == D3D_REGISTER_COMPONENT_FLOAT32) elementDesc.Format = DXGI_FORMAT_R32G32B32_FLOAT; }
		else if (paramDesc.Mask <= 15) { if (paramDesc.ComponentType == D3D_REGISTER_COMPONENT_UINT32) elementDesc.Format = DXGI_FORMAT_R32G32B32A32_UINT;  else if (paramDesc.ComponentType == D3D_REGISTER_COMPONENT_SINT32) elementDesc.Format = DXGI_FORMAT_R32G32B32A32_SINT;  else if (paramDesc.ComponentType == D3D_REGISTER_COMPONENT_FLOAT32) elementDesc.Format = DXGI_FORMAT_R32G32B32A32_FLOAT; }

		std::string name = paramDesc.SemanticName;
		std::transform(name.begin(), name.end(), name.begin(), toupper);

		if (name == "POSITION")
			elementDesc.Format = DXGI_FORMAT_R32G32B32_FLOAT;

		if (Utils::StartsWith(name, "INST"))
		{
			elementDesc.InputSlot = 1;
			elementDesc.AlignedByteOffset = D3D11_APPEND_ALIGNED_ELEMENT;
			elementDesc.InputSlotClass = D3D11_INPUT_PER_INSTANCE_DATA;
			elementDesc.InstanceDataStepRate = 1;
		}

		if (!Utils::StartsWith(name, "SV_"))
			inputLayoutDesc.push_back(elementDesc);
	}

	const void* code = effectVsDesc->pBytecode;
	UINT        codeSize = effectVsDesc->BytecodeLength;

	if (!inputLayoutDesc.empty())
	{
		ComPtr<ID3D11InputLayout> inputLayout;
		HRESULT hr = GET_SINGLE(Graphics)->GetDevice()->CreateInputLayout(
			inputLayoutDesc.data(), static_cast<UINT>(inputLayoutDesc.size()),
			code, codeSize, inputLayout.GetAddressOf());
		CHECK(hr);
		return inputLayout;
	}

	return nullptr;
}

// ── Draw 위임 ─────────────────────────────────────────────────────────────

void Shader::Draw(UINT technique, UINT pass, UINT vertexCount, UINT startVertexLocation)
{
	_techniques[technique].passes[pass].Draw(vertexCount, startVertexLocation);
}

void Shader::DrawIndexed(UINT technique, UINT pass, UINT indexCount, UINT startIndexLocation, INT baseVertexLocation)
{
	_techniques[technique].passes[pass].DrawIndexed(indexCount, startIndexLocation, baseVertexLocation);
}

void Shader::DrawInstanced(UINT technique, UINT pass, UINT vertexCountPerInstance, UINT instanceCount, UINT startVertexLocation, UINT startInstanceLocation)
{
	_techniques[technique].passes[pass].DrawInstanced(vertexCountPerInstance, instanceCount, startVertexLocation, startInstanceLocation);
}

void Shader::DrawIndexedInstanced(UINT technique, UINT pass, UINT indexCountPerInstance, UINT instanceCount, UINT startIndexLocation, INT baseVertexLocation, UINT startInstanceLocation)
{
	_techniques[technique].passes[pass].DrawIndexedInstanced(indexCountPerInstance, instanceCount, startIndexLocation, baseVertexLocation, startInstanceLocation);
}

void Shader::Dispatch(UINT technique, UINT pass, UINT x, UINT y, UINT z)
{
	_techniques[technique].passes[pass].Dispatch(x, y, z);
}

// ── GetVariable 계열 (변경 없음) ──────────────────────────────────────────
ComPtr<ID3DX11EffectVariable>                    Shader::GetVariable(const std::string& n) { return _shaderDesc.effect->GetVariableByName(n.c_str()); }
ComPtr<ID3DX11EffectScalarVariable>              Shader::GetScalar(const std::string& n) { return _shaderDesc.effect->GetVariableByName(n.c_str())->AsScalar(); }
ComPtr<ID3DX11EffectVectorVariable>              Shader::GetVector(const std::string& n) { return _shaderDesc.effect->GetVariableByName(n.c_str())->AsVector(); }
ComPtr<ID3DX11EffectMatrixVariable>              Shader::GetMatrix(const std::string& n) { return _shaderDesc.effect->GetVariableByName(n.c_str())->AsMatrix(); }
ComPtr<ID3DX11EffectStringVariable>              Shader::GetString(const std::string& n) { return _shaderDesc.effect->GetVariableByName(n.c_str())->AsString(); }
ComPtr<ID3DX11EffectShaderResourceVariable>      Shader::GetSRV(const std::string& n) { return _shaderDesc.effect->GetVariableByName(n.c_str())->AsShaderResource(); }
ComPtr<ID3DX11EffectRenderTargetViewVariable>    Shader::GetRTV(const std::string& n) { return _shaderDesc.effect->GetVariableByName(n.c_str())->AsRenderTargetView(); }
ComPtr<ID3DX11EffectDepthStencilViewVariable>    Shader::GetDSV(const std::string& n) { return _shaderDesc.effect->GetVariableByName(n.c_str())->AsDepthStencilView(); }
ComPtr<ID3DX11EffectConstantBuffer>              Shader::GetConstantBuffer(const std::string& n) { return _shaderDesc.effect->GetConstantBufferByName(n.c_str()); }
ComPtr<ID3DX11EffectShaderVariable>              Shader::GetShader(const std::string& n) { return _shaderDesc.effect->GetVariableByName(n.c_str())->AsShader(); }
ComPtr<ID3DX11EffectBlendVariable>               Shader::GetBlend(const std::string& n) { return _shaderDesc.effect->GetVariableByName(n.c_str())->AsBlend(); }
ComPtr<ID3DX11EffectDepthStencilVariable>        Shader::GetDepthStencil(const std::string& n) { return _shaderDesc.effect->GetVariableByName(n.c_str())->AsDepthStencil(); }
ComPtr<ID3DX11EffectRasterizerVariable>          Shader::GetRasterizer(const std::string& n) { return _shaderDesc.effect->GetVariableByName(n.c_str())->AsRasterizer(); }
ComPtr<ID3DX11EffectSamplerVariable>             Shader::GetSampler(const std::string& n) { return _shaderDesc.effect->GetVariableByName(n.c_str())->AsSampler(); }
ComPtr<ID3DX11EffectUnorderedAccessViewVariable> Shader::GetUAV(const std::string& n) { return _shaderDesc.effect->GetVariableByName(n.c_str())->AsUnorderedAccessView(); }

// ── Push 상수버퍼 계열 (shared_ptr → unique_ptr) ──────────────────────────
void Shader::PushGlobalData(const Matrix& view, const Matrix& projection)
{
	if (_globalEffectBuffer == nullptr)
		_globalEffectBuffer = GetConstantBuffer("GlobalBuffer");

	GET_SINGLE(SharedCBufferManager)->SetGlobal(view, projection);
	_globalEffectBuffer->SetConstantBuffer(GET_SINGLE(SharedCBufferManager)->GetGlobalBuffer());
}

void Shader::PushTransformData(const TransformDesc& desc)
{
	if (_transformEffectBuffer == nullptr)
	{
		_transformBuffer = std::make_unique<ConstantBuffer<TransformDesc>>();
		_transformBuffer->Create(GET_SINGLE(Graphics)->GetDevice());
		_transformEffectBuffer = GetConstantBuffer("TransformBuffer");
	}
	_transformDesc = desc;
	_transformBuffer->CopyData(GET_SINGLE(Graphics)->GetDeviceContext(), _transformDesc);
	_transformEffectBuffer->SetConstantBuffer(_transformBuffer->GetComPtr().Get());
}

void Shader::PushLightData(const LightDesc& desc)
{
	if (_lightEffectBuffer == nullptr)
		_lightEffectBuffer = GetConstantBuffer("LightBuffer");

	GET_SINGLE(SharedCBufferManager)->SetLight(desc);
	_lightEffectBuffer->SetConstantBuffer(GET_SINGLE(SharedCBufferManager)->GetLightBuffer());
}

void Shader::PushMaterialData(const MaterialDesc& desc)
{
	if (_materialEffectBuffer == nullptr)
	{
		_materialBuffer = std::make_unique<ConstantBuffer<MaterialDesc>>();
		_materialBuffer->Create(GET_SINGLE(Graphics)->GetDevice());
		_materialEffectBuffer = GetConstantBuffer("MaterialBuffer");
	}

	if (::memcmp(&_materialDesc, &desc, sizeof(MaterialDesc)) == 0) return;

	_materialDesc = desc;
	_materialBuffer->CopyData(GET_SINGLE(Graphics)->GetDeviceContext(), _materialDesc);
	_materialEffectBuffer->SetConstantBuffer(_materialBuffer->GetComPtr().Get());
}

void Shader::PushBoneData(const BoneDesc& desc)
{
	if (_boneEffectBuffer == nullptr)
	{
		_boneBuffer = std::make_unique<ConstantBuffer<BoneDesc>>();
		_boneBuffer->Create(GET_SINGLE(Graphics)->GetDevice());
		_boneEffectBuffer = GetConstantBuffer("BoneBuffer");
	}
	_boneDesc = desc;
	_boneBuffer->CopyData(GET_SINGLE(Graphics)->GetDeviceContext(), _boneDesc);
	_boneEffectBuffer->SetConstantBuffer(_boneBuffer->GetComPtr().Get());
}

void Shader::PushKeyframeData(const KeyframeDesc& desc)
{
	if (_keyframeEffectBuffer == nullptr)
	{
		_keyframeBuffer = std::make_unique<ConstantBuffer<KeyframeDesc>>();
		_keyframeBuffer->Create(GET_SINGLE(Graphics)->GetDevice());
		_keyframeEffectBuffer = GetConstantBuffer("KeyframeBuffer");
	}
	_keyframeDesc = desc;
	_keyframeBuffer->CopyData(GET_SINGLE(Graphics)->GetDeviceContext(), _keyframeDesc);
	_keyframeEffectBuffer->SetConstantBuffer(_keyframeBuffer->GetComPtr().Get());
}

void Shader::PushTweenData(const InstancedTweenDesc& desc)
{
	if (_tweenEffectBuffer == nullptr)
	{
		_tweenBuffer = std::make_unique<ConstantBuffer<InstancedTweenDesc>>();
		_tweenBuffer->Create(GET_SINGLE(Graphics)->GetDevice());
		_tweenEffectBuffer = GetConstantBuffer("TweenBuffer");
	}
	_tweenDesc = desc;
	_tweenBuffer->CopyData(GET_SINGLE(Graphics)->GetDeviceContext(), _tweenDesc);
	_tweenEffectBuffer->SetConstantBuffer(_tweenBuffer->GetComPtr().Get());
}

// ── ShaderManager ─────────────────────────────────────────────────────────
std::unordered_map<std::wstring, ShaderDesc> ShaderManager::shaders;

ShaderDesc ShaderManager::GetEffect(const std::wstring& fileName)
{
	if (shaders.count(fileName) == 0)
	{
		ComPtr<ID3DBlob> blob, error;
		INT flag = D3D10_SHADER_ENABLE_BACKWARDS_COMPATIBILITY | D3D10_SHADER_PACK_MATRIX_ROW_MAJOR;

		HRESULT hr = ::D3DCompileFromFile(fileName.c_str(), nullptr, D3D_COMPILE_STANDARD_FILE_INCLUDE,
			nullptr, "fx_5_0", flag, NULL, blob.GetAddressOf(), error.GetAddressOf());
		if (FAILED(hr))
		{
			if (error != nullptr)
				MessageBoxA(nullptr, (const char*)error->GetBufferPointer(), "Shader Error", MB_OK);
			assert(false);
		}

		ComPtr<ID3DX11Effect> effect;
		hr = ::D3DX11CreateEffectFromMemory(blob->GetBufferPointer(), blob->GetBufferSize(),
			0, GET_SINGLE(Graphics)->GetDevice().Get(), effect.GetAddressOf());
		CHECK(hr);

		shaders[fileName] = ShaderDesc{ blob, effect };
	}

	ShaderDesc desc = shaders.at(fileName);
	ComPtr<ID3DX11Effect> effect;
	desc.effect->CloneEffect(D3DX11_EFFECT_CLONE_FORCE_NONSINGLE, effect.GetAddressOf());
	return ShaderDesc{ desc.blob, effect };
}

void Shader::PushShadowData(const ShadowDesc& desc, ID3D11ShaderResourceView* shadowSrv)
{
	if (_shadowEffectBuffer == nullptr)
	{
		_shadowBuffer = std::make_unique<ConstantBuffer<ShadowDesc>>();
		_shadowBuffer->Create(GET_SINGLE(Graphics)->GetDevice());
		_shadowEffectBuffer = GetConstantBuffer("ShadowBuffer");
		if (_shadowEffectBuffer == nullptr) return;
	}

	if (::memcmp(&_shadowDesc, &desc, sizeof(ShadowDesc)) != 0)
	{
		_shadowDesc = desc;
		_shadowBuffer->CopyData(GET_SINGLE(Graphics)->GetDeviceContext(), _shadowDesc);
		_shadowEffectBuffer->SetConstantBuffer(_shadowBuffer->GetComPtr().Get());
	}

	auto shadowMapVar = GetSRV("ShadowMap");
	if (shadowMapVar) shadowMapVar->SetResource(shadowSrv);
}

bool Shader::HasVariable(const std::string& name) const
{
	D3DX11_EFFECT_DESC effectDesc = {};
	if (FAILED(_shaderDesc.effect->GetDesc(&effectDesc)))
		return false;

	for (UINT i = 0; i < effectDesc.GlobalVariables; ++i)
	{
		ID3DX11EffectVariable* var = _shaderDesc.effect->GetVariableByIndex(i);
		if (!var) continue;

		D3DX11_EFFECT_VARIABLE_DESC varDesc = {};
		if (SUCCEEDED(var->GetDesc(&varDesc)) && name == varDesc.Name)
			return true;
	}
	return false;
}
