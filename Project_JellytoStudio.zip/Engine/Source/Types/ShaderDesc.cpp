﻿
#include "Framework.h"
#include "ShaderDesc.h"

/////////////////////////
/// No implementation ///
/////////////////////////