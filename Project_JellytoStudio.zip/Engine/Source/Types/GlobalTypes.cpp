#include "Framework.h"
#include "GlobalTypes.h"

/////////////////////////
/// No implementation ///
/////////////////////////