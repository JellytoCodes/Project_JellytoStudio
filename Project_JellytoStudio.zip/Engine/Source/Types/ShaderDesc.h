﻿#pragma once

struct GlobalDesc
{
    Matrix V   = Matrix::Identity;
    Matrix P   = Matrix::Identity;
    Matrix VP  = Matrix::Identity;
    Matrix VInv = Matrix::Identity;
};

struct TransformDesc
{
    Matrix W = Matrix::Identity;
};

struct LightDesc
{
    Color ambient  = Color(1.f, 1.f, 1.f, 1.f);
    Color diffuse  = Color(1.f, 1.f, 1.f, 1.f);
    Color specular = Color(1.f, 1.f, 1.f, 1.f);
    Color emissive = Color(1.f, 1.f, 1.f, 1.f);

    Vec3  direction;
    float padding0 = 0.f;
};

struct MaterialDesc
{
    Color ambient  = Color(0.f, 0.f, 0.f, 1.f);
    Color diffuse  = Color(1.f, 1.f, 1.f, 1.f);
    Color specular = Color(0.f, 0.f, 0.f, 1.f);
    Color emissive = Color(0.f, 0.f, 0.f, 1.f);
};

#define MAX_MODEL_TRANSFORMS 250
#define MAX_MODEL_KEYFRAMES  500
#define MAX_MODEL_INSTANCE   250

struct BoneDesc
{
    Matrix transforms[MAX_MODEL_TRANSFORMS];
};

struct KeyframeDesc
{
    int32  animIndex = 0;
    uint32 currFrame = 0;
    uint32 nextFrame = 0;
    float  ratio     = 0;

    float  sumTime   = 0;
    float  speed     = 1.f;
    Vec2   padding;
};

struct TweenDesc
{
    TweenDesc()
    {
        curr.animIndex = 0;
        next.animIndex = -1;
    }

    void ClearNextAnim()
    {
        next.animIndex = -1;
        next.currFrame = 0;
        next.nextFrame = 0;
        next.sumTime   = 0;
        tweenSumTime   = 0;
        tweenRatio     = 0;
    }

    float        tweenDuration = 1.f;
    float        tweenRatio    = 0.f;
    float        tweenSumTime  = 0.f;
    float        padding       = 0.f;

    KeyframeDesc curr;
    KeyframeDesc next;
};

struct InstancedTweenDesc
{
    TweenDesc tweens[MAX_MODEL_INSTANCE];
};

struct ShadowDesc
{
    Matrix lightVP   = Matrix::Identity;
    float  bias      = 0.003f;
    float  texelSize = 1.0f / 1024.0f;
    float  pad[2]    = {};
};
